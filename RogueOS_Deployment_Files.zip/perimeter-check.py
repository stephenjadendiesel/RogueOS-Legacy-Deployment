"""
RogueOS Perimeter Check Module
Simulates a basic scan for potential threats or unknown network activities.
"""

import socket
import os
import time

def scan_port(host, port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        try:
            s.connect((host, port))
            return True
        except:
            return False

def perimeter_check():
    suspicious_ports = [21, 23, 80, 443, 8080]
    host = "127.0.0.1"
    print(f"Scanning {host} for known open ports...")
    for port in suspicious_ports:
        if scan_port(host, port):
            print(f"[!] Port {port} is OPEN — flagging for review.")
        else:
            print(f"[✓] Port {port} is CLOSED.")

if __name__ == "__main__":
    perimeter_check()
